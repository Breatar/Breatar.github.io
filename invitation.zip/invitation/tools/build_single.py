# -*- coding: utf-8 -*-
"""把 src/page.html 里引用的 assets/ 图片全部内联成 data URI，输出单文件 index.html。

用法：
    python tools/build_single.py            # 打包
之后 index.html 可以单独发给别人，不依赖任何外部文件。

换图流程：把新照片放进 assets/img/（同名或改 src/page.html 里的引用），再跑一次本脚本。
"""
import os
import re
import base64
import mimetypes

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, 'src', 'page.html')
OUT = os.path.join(ROOT, 'index.html')

MIME = {
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
}

html = open(SRC, encoding='utf-8').read()
paths = sorted(set(re.findall(r'assets/[A-Za-z0-9_./-]+', html)))

total = 0
for p in paths:
    full = os.path.join(ROOT, p)
    if not os.path.exists(full):
        print('MISSING', p)
        continue
    ext = os.path.splitext(p)[1].lower()
    mime = MIME.get(ext) or mimetypes.guess_type(p)[0] or 'application/octet-stream'
    raw = open(full, 'rb').read()
    b64 = base64.b64encode(raw).decode('ascii')
    uri = 'data:%s;base64,%s' % (mime, b64)
    html = html.replace(p, uri)
    total += len(raw)
    print('inline %-24s %7d B -> %8d B' % (p, len(raw), len(uri)))

left = re.findall(r'assets/[A-Za-z0-9_./-]+', html)
print('remaining external refs:', left or 'none')
if left:
    raise SystemExit('still has external refs')

open(OUT, 'w', encoding='utf-8').write(html)
print('---')
print('wrote', OUT)
print('size: %.1f KB' % (os.path.getsize(OUT) / 1024))
print('images inlined: %d files, %.1f KB raw' % (len(paths), total / 1024))
