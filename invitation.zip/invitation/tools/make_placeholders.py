# -*- coding: utf-8 -*-
"""生成邀请函用的占位图片（SVG）。

后期替换方式：直接把 assets/img 下同名文件换成真实图片即可（保持文件名不变），
或在 index.html 顶部的 IMAGES 配置里改成自己的图片地址。
"""
import math
import os

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "img")
os.makedirs(OUT, exist_ok=True)

GOLD = ["#f6e6bb", "#e4c886", "#c9a24d", "#9a7530"]


def write(name, svg):
    path = os.path.join(OUT, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(svg.strip() + "\n")
    print("written", name, len(svg), "bytes")


def star(cx, cy, r, fill="#f6e6bb", op=1.0):
    pts = []
    for i in range(16):
        ang = math.pi / 2 - i * math.pi / 8
        rr = r if i % 4 == 0 else (r * 0.72 if i % 2 == 0 else r * 0.28)
        pts.append(f"{cx + rr * math.cos(ang):.2f},{cy - rr * math.sin(ang):.2f}")
    return f'<polygon points="{" ".join(pts)}" fill="{fill}" opacity="{op}"/>'


def blossom(cx, cy, r, color, op=0.9):
    """五瓣梅花，用圆形做花瓣。"""
    out = []
    for i in range(5):
        ang = math.pi / 2 + i * 2 * math.pi / 5
        px = cx + r * 0.62 * math.cos(ang)
        py = cy - r * 0.62 * math.sin(ang)
        out.append(f'<circle cx="{px:.2f}" cy="{py:.2f}" r="{r * 0.52:.2f}" fill="{color}" opacity="{op}"/>')
    out.append(f'<circle cx="{cx:.2f}" cy="{cy:.2f}" r="{r * 0.14:.2f}" fill="#8c2a20" opacity="0.55"/>')
    return "".join(out)


# ---------------------------------------------------------------- 主视觉
hero = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1300" width="1000" height="1300" role="img" aria-label="主视觉占位图">
  <defs>
    <linearGradient id="sky" x1="0" y1="0" x2="0.25" y2="1">
      <stop offset="0" stop-color="#1b0e11"/>
      <stop offset="0.45" stop-color="#40161a"/>
      <stop offset="0.78" stop-color="#6a241f"/>
      <stop offset="1" stop-color="#3a1416"/>
    </linearGradient>
    <radialGradient id="moon" cx="0.42" cy="0.38" r="0.62">
      <stop offset="0" stop-color="#fffaea"/>
      <stop offset="0.62" stop-color="#f4dfae"/>
      <stop offset="1" stop-color="#d9b878"/>
    </radialGradient>
    <radialGradient id="halo" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="#ffdfa6" stop-opacity="0.55"/>
      <stop offset="0.45" stop-color="#e8b978" stop-opacity="0.18"/>
      <stop offset="1" stop-color="#e8b978" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="goldline" x1="0" y1="0" x2="1" y2="0.3">
      <stop offset="0" stop-color="#c9a24d" stop-opacity="0.1"/>
      <stop offset="0.5" stop-color="#f6e6bb" stop-opacity="0.85"/>
      <stop offset="1" stop-color="#c9a24d" stop-opacity="0.1"/>
    </linearGradient>
    <linearGradient id="mtn1" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#58201f"/>
      <stop offset="1" stop-color="#2b1013"/>
    </linearGradient>
    <linearGradient id="mtn2" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#3a1518"/>
      <stop offset="1" stop-color="#1a0b0d"/>
    </linearGradient>
    <radialGradient id="vig" cx="0.5" cy="0.45" r="0.72">
      <stop offset="0.55" stop-color="#000" stop-opacity="0"/>
      <stop offset="1" stop-color="#000" stop-opacity="0.62"/>
    </radialGradient>
    <filter id="soft"><feGaussianBlur stdDeviation="9"/></filter>
    <filter id="softer"><feGaussianBlur stdDeviation="22"/></filter>
    <filter id="grain">
      <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" result="n"/>
      <feColorMatrix in="n" type="saturate" values="0"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.16"/></feComponentTransfer>
    </filter>
  </defs>

  <rect width="1000" height="1300" fill="url(#sky)"/>
  <circle cx="486" cy="402" r="400" fill="url(#halo)"/>
  <circle cx="486" cy="402" r="132" fill="url(#moon)" opacity="0.96"/>

  <!-- 云雾 -->
  <g filter="url(#softer)" opacity="0.5">
    <ellipse cx="300" cy="560" rx="330" ry="40" fill="#e0b98a" opacity="0.22"/>
    <ellipse cx="740" cy="600" rx="300" ry="34" fill="#e0b98a" opacity="0.16"/>
  </g>

  <!-- 远山 -->
  <path d="M0 706 L96 636 L180 686 L286 594 L392 690 L470 640 L576 706 L688 620 L800 700 L900 646 L1000 700 L1000 1300 L0 1300 Z"
        fill="#612523" opacity="0.5" filter="url(#soft)"/>
  <!-- 中山 -->
  <path d="M0 772 L120 706 L226 762 L344 690 L462 774 L580 712 L690 780 L806 716 L910 776 L1000 736 L1000 1300 L0 1300 Z"
        fill="url(#mtn1)" opacity="0.92"/>
  <!-- 近山 -->
  <path d="M0 916 L150 862 L300 920 L440 868 L590 934 L740 876 L880 934 L1000 900 L1000 1300 L0 1300 Z"
        fill="url(#mtn2)"/>

  <!-- 金线祥云 -->
  <g fill="none" stroke="url(#goldline)" stroke-width="2.2" stroke-linecap="round">
    <path d="M150 800 q34 -34 68 0 q34 -34 68 0"/>
    <path d="M232 836 q30 -30 60 0 q30 -30 60 0"/>
    <path d="M700 790 q34 -34 68 0 q34 -34 68 0"/>
    <path d="M640 830 q30 -30 60 0 q30 -30 60 0"/>
    <path d="M100 1120 q36 -36 72 0 q36 -36 72 0"/>
    <path d="M760 1110 q36 -36 72 0 q36 -36 72 0"/>
  </g>
  <!-- 飞鸟 -->
  <g stroke="#f0d9a8" stroke-opacity="0.5" stroke-width="2" fill="none" stroke-linecap="round">
    <path d="M690 330 q12 -12 24 0 q12 -12 24 0"/>
    <path d="M744 374 q9 -9 18 0 q9 -9 18 0"/>
    <path d="M636 384 q8 -8 16 0 q8 -8 16 0"/>
  </g>

  <!-- 金色细边 -->
  <rect x="34" y="34" width="932" height="1232" fill="none" stroke="#e4c886" stroke-opacity="0.28" stroke-width="2"/>
  <rect x="52" y="52" width="896" height="1196" fill="none" stroke="#e4c886" stroke-opacity="0.14" stroke-width="1"/>

  <rect width="1000" height="1300" fill="url(#vig)"/>
  <rect width="1000" height="1300" filter="url(#grain)" opacity="0.55"/>
  <text x="936" y="1250" text-anchor="end" font-family="Songti SC, SimSun, serif" font-size="20"
        letter-spacing="6" fill="#f6e6bb" fill-opacity="0.34">主视觉占位 · hero.svg</text>
</svg>"""
write("hero.svg", hero)


# ---------------------------------------------------------------- 相册 1：梅枝
branches = []
pts = [(120, 940), (240, 840), (330, 700), (410, 556), (500, 430), (560, 300), (600, 180)]
for i in range(len(pts) - 1):
    (x1, y1), (x2, y2) = pts[i], pts[i + 1]
    mx, my = (x1 + x2) / 2 - 26, (y1 + y2) / 2 + 14
    branches.append(f'<path d="M{x1} {y1} Q{mx} {my} {x2} {y2}" stroke="url(#g1)" stroke-width="{9 - i}" '
                    f'fill="none" stroke-linecap="round"/>')
twig = [(330, 700, 470, 660), (410, 556, 300, 470), (500, 430, 640, 400), (560, 300, 470, 214)]
for x1, y1, x2, y2 in twig:
    branches.append(f'<path d="M{x1} {y1} Q{(x1 + x2) / 2} {(y1 + y2) / 2 - 30} {x2} {y2}" stroke="url(#g1)" '
                    f'stroke-width="3.4" fill="none" stroke-linecap="round" opacity="0.85"/>')

flowers = [(470, 650, 34), (300, 462, 26), (648, 392, 30), (462, 206, 22), (206, 792, 20), (386, 760, 17)]
fl = "".join(blossom(x, y, r, "#e9c98e", 0.92) for x, y, r in flowers)

p1 = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 900" width="900" height="900" role="img" aria-label="相册占位图一">
  <defs>
    <radialGradient id="bg1" cx="0.32" cy="0.28" r="0.95">
      <stop offset="0" stop-color="#5d2320"/>
      <stop offset="0.55" stop-color="#3a1416"/>
      <stop offset="1" stop-color="#1d0c0e"/>
    </radialGradient>
    <linearGradient id="g1" x1="0" y1="1" x2="0.6" y2="0">
      <stop offset="0" stop-color="#8a6526"/>
      <stop offset="0.5" stop-color="#e4c886"/>
      <stop offset="1" stop-color="#f6e6bb"/>
    </linearGradient>
    <filter id="grain1">
      <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3"/>
      <feColorMatrix type="saturate" values="0"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.14"/></feComponentTransfer>
    </filter>
  </defs>
  <rect width="900" height="900" fill="url(#bg1)"/>
  <circle cx="690" cy="180" r="120" fill="#f4dfae" opacity="0.08"/>
  {"".join(branches)}
  {fl}
  <rect x="26" y="26" width="848" height="848" fill="none" stroke="#e4c886" stroke-opacity="0.22"/>
  <rect width="900" height="900" filter="url(#grain1)" opacity="0.5"/>
  <text x="874" y="862" text-anchor="end" font-family="Songti SC, SimSun, serif" font-size="18"
        letter-spacing="5" fill="#f6e6bb" fill-opacity="0.32">相册占位 01 · photo-1.svg</text>
</svg>"""
write("photo-1.svg", p1)


# ---------------------------------------------------------------- 相册 2：团花窗棂
rings, petals = [], []
for i, r in enumerate([300, 262, 232]):
    rings.append(f'<circle cx="450" cy="450" r="{r}" fill="none" stroke="url(#g2)" stroke-width="{2.4 - i * 0.4}" opacity="{0.8 - i * 0.18}"/>')
for i in range(24):
    ang = i * 2 * math.pi / 24
    r1, r2 = 232, 300 if i % 2 == 0 else 268
    petals.append(f'<line x1="{450 + r1 * math.cos(ang):.1f}" y1="{450 + r1 * math.sin(ang):.1f}" '
                  f'x2="{450 + r2 * math.cos(ang):.1f}" y2="{450 + r2 * math.sin(ang):.1f}" stroke="url(#g2)" stroke-width="1.6" opacity="0.55"/>')
inner = []
for i in range(8):
    ang = i * 2 * math.pi / 8
    x1, y1 = 450 + 96 * math.cos(ang), 450 + 96 * math.sin(ang)
    x2, y2 = 450 + 196 * math.cos(ang), 450 + 196 * math.sin(ang)
    cx, cy = 450 + 150 * math.cos(ang + 0.4), 450 + 150 * math.sin(ang + 0.4)
    inner.append(f'<path d="M{x1:.1f} {y1:.1f} Q{cx:.1f} {cy:.1f} {x2:.1f} {y2:.1f}" fill="none" stroke="url(#g2)" stroke-width="2.6" opacity="0.8"/>')

p2 = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 900" width="900" height="900" role="img" aria-label="相册占位图二">
  <defs>
    <radialGradient id="bg2" cx="0.5" cy="0.42" r="0.78">
      <stop offset="0" stop-color="#4a1c1c"/>
      <stop offset="0.6" stop-color="#2d1113"/>
      <stop offset="1" stop-color="#180a0c"/>
    </radialGradient>
    <linearGradient id="g2" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#f6e6bb"/>
      <stop offset="0.5" stop-color="#c9a24d"/>
      <stop offset="1" stop-color="#f6e6bb"/>
    </linearGradient>
    <filter id="grain2">
      <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3"/>
      <feColorMatrix type="saturate" values="0"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.13"/></feComponentTransfer>
    </filter>
  </defs>
  <rect width="900" height="900" fill="url(#bg2)"/>
  <g opacity="0.5">
    <rect x="70" y="70" width="760" height="760" fill="none" stroke="#e4c886" stroke-opacity="0.16"/>
    <line x1="70" y1="450" x2="830" y2="450" stroke="#e4c886" stroke-opacity="0.12"/>
    <line x1="450" y1="70" x2="450" y2="830" stroke="#e4c886" stroke-opacity="0.12"/>
  </g>
  {"".join(rings)}
  {"".join(petals)}
  {"".join(inner)}
  <circle cx="450" cy="450" r="78" fill="none" stroke="url(#g2)" stroke-width="2.4" opacity="0.9"/>
  <text x="450" y="482" text-anchor="middle" font-family="Songti SC, SimSun, serif" font-size="86"
        fill="#f6e6bb" fill-opacity="0.9" letter-spacing="0">囍</text>
  <rect width="900" height="900" filter="url(#grain2)" opacity="0.5"/>
  <text x="874" y="862" text-anchor="end" font-family="Songti SC, SimSun, serif" font-size="18"
        letter-spacing="5" fill="#f6e6bb" fill-opacity="0.32">相册占位 02 · photo-2.svg</text>
</svg>"""
write("photo-2.svg", p2)


# ---------------------------------------------------------------- 相册 3：灯笼与云
p3 = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 900" width="900" height="900" role="img" aria-label="相册占位图三">
  <defs>
    <linearGradient id="bg3" x1="0" y1="0" x2="0.4" y2="1">
      <stop offset="0" stop-color="#571f1d"/>
      <stop offset="0.55" stop-color="#33120f"/>
      <stop offset="1" stop-color="#170a09"/>
    </linearGradient>
    <radialGradient id="lamp" cx="0.5" cy="0.42" r="0.6">
      <stop offset="0" stop-color="#ffd9a0" stop-opacity="0.9"/>
      <stop offset="1" stop-color="#d96b3c" stop-opacity="0.25"/>
    </radialGradient>
    <linearGradient id="g3" x1="0" y1="0" x2="1" y2="0.6">
      <stop offset="0" stop-color="#f6e6bb"/>
      <stop offset="0.5" stop-color="#c9a24d"/>
      <stop offset="1" stop-color="#f6e6bb"/>
    </linearGradient>
    <filter id="glow"><feGaussianBlur stdDeviation="26"/></filter>
    <filter id="grain3">
      <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3"/>
      <feColorMatrix type="saturate" values="0"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.13"/></feComponentTransfer>
    </filter>
  </defs>
  <rect width="900" height="900" fill="url(#bg3)"/>
  <ellipse cx="450" cy="400" rx="260" ry="230" fill="url(#lamp)" filter="url(#glow)"/>
  <!-- 灯笼 -->
  <g stroke="url(#g3)" fill="none" stroke-width="2.6" stroke-linecap="round">
    <path d="M450 120 v60"/>
    <rect x="414" y="180" width="72" height="24" rx="6"/>
    <path d="M352 260 q98 -52 196 0"/>
    <path d="M352 260 q-46 130 0 260 q98 54 196 0 q46 -130 0 -260"/>
    <g opacity="0.5" stroke-width="1.4">
      <path d="M382 236 q-24 140 0 292"/>
      <path d="M420 226 q-14 150 0 314"/>
      <path d="M450 222 v322"/>
      <path d="M480 226 q14 150 0 314"/>
      <path d="M518 236 q24 140 0 292"/>
    </g>
    <path d="M352 520 q98 46 196 0"/>
    <rect x="414" y="536" width="72" height="22" rx="5"/>
    <path d="M450 558 v54"/>
    <g opacity="0.85">
      <path d="M450 612 q-26 44 -8 96"/>
      <path d="M450 612 q26 44 8 96"/>
      <path d="M450 612 v104"/>
    </g>
  </g>
  <!-- 祥云 -->
  <g fill="none" stroke="#e4c886" stroke-opacity="0.42" stroke-width="2" stroke-linecap="round">
    <path d="M120 780 q40 -40 80 0 q40 -40 80 0"/>
    <path d="M184 818 q34 -34 68 0 q34 -34 68 0"/>
    <path d="M610 742 q40 -40 80 0 q40 -40 80 0"/>
    <path d="M548 786 q34 -34 68 0 q34 -34 68 0"/>
  </g>
  <g fill="#f6e6bb" opacity="0.5">
    {star(180, 220, 12)} {star(742, 300, 9)} {star(690, 150, 7)} {star(238, 380, 8)}
  </g>
  <rect x="26" y="26" width="848" height="848" fill="none" stroke="#e4c886" stroke-opacity="0.2"/>
  <rect width="900" height="900" filter="url(#grain3)" opacity="0.5"/>
  <text x="874" y="862" text-anchor="end" font-family="Songti SC, SimSun, serif" font-size="18"
        letter-spacing="5" fill="#f6e6bb" fill-opacity="0.32">相册占位 03 · photo-3.svg</text>
</svg>"""
write("photo-3.svg", p3)


# ---------------------------------------------------------------- 地图
roads = """
  <g stroke="#cdbfa4" fill="none" stroke-linecap="round">
    <path d="M-20 320 C 160 300, 240 372, 430 350 C 620 328, 720 250, 940 268" stroke-width="16"/>
    <path d="M120 -20 C 150 160, 96 300, 168 470 C 226 610, 210 740, 240 900" stroke-width="12"/>
    <path d="M640 -20 C 610 150, 700 268, 676 420 C 654 560, 720 700, 690 900" stroke-width="10"/>
    <path d="M-20 640 C 190 600, 330 690, 520 660 C 700 632, 800 700, 940 676" stroke-width="7"/>
  </g>
"""
map_svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 520" width="900" height="520" role="img" aria-label="位置示意图占位">
  <defs>
    <linearGradient id="paper" x1="0" y1="0" x2="0.6" y2="1">
      <stop offset="0" stop-color="#f7f1e4"/>
      <stop offset="1" stop-color="#e8ddc7"/>
    </linearGradient>
    <radialGradient id="pinGlow" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="#a52a24" stop-opacity="0.35"/>
      <stop offset="1" stop-color="#a52a24" stop-opacity="0"/>
    </radialGradient>
    <filter id="mgrain">
      <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3"/>
      <feColorMatrix type="saturate" values="0"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.1"/></feComponentTransfer>
    </filter>
  </defs>
  <rect width="900" height="520" fill="url(#paper)"/>
  <g opacity="0.35" stroke="#c8b795" stroke-width="1">
    {''.join(f'<line x1="0" y1="{y}" x2="900" y2="{y}"/>' for y in range(40, 520, 40))}
    {''.join(f'<line x1="{x}" y1="0" x2="{x}" y2="520"/>' for x in range(40, 900, 40))}
  </g>
  <path d="M-20 120 C 180 96, 300 190, 470 150 C 640 112, 760 60, 940 96 L 940 8 L -20 8 Z" fill="#dfe9e2" opacity="0.8"/>
  {roads}
  <g fill="#cabc9f" opacity="0.75">
    <rect x="300" y="392" width="86" height="58" rx="6"/>
    <rect x="410" y="392" width="66" height="58" rx="6"/>
    <rect x="300" y="466" width="120" height="44" rx="6"/>
    <rect x="560" y="150" width="96" height="64" rx="6"/>
    <rect x="686" y="150" width="70" height="64" rx="6"/>
    <rect x="560" y="240" width="70" height="52" rx="6"/>
  </g>
  <circle cx="452" cy="300" r="120" fill="url(#pinGlow)"/>
  <g transform="translate(452 300)">
    <path d="M0 -68 C 34 -68 62 -40 62 -6 C 62 36 0 84 0 84 C 0 84 -62 36 -62 -6 C -62 -40 -34 -68 0 -68 Z"
          fill="#a52a24" stroke="#f0d9a8" stroke-width="3"/>
    <circle cx="0" cy="-8" r="22" fill="#f7f1e4"/>
    <circle cx="0" cy="-8" r="10" fill="#a52a24"/>
  </g>
  <rect x="18" y="18" width="864" height="484" fill="none" stroke="#b9a67e" stroke-opacity="0.6"/>
  <rect width="900" height="520" filter="url(#mgrain)" opacity="0.5"/>
  <text x="880" y="492" text-anchor="end" font-family="Songti SC, SimSun, serif" font-size="18"
        letter-spacing="4" fill="#8a7a5c" fill-opacity="0.75">位置示意 · map.svg</text>
</svg>"""
write("map.svg", map_svg)
print("done")
